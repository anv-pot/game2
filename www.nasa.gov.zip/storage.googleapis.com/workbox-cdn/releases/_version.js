"use strict";
// @ts-ignore
try {
    self['workbox:strategies:6.2.0'] && _();
}
catch (e) { }
